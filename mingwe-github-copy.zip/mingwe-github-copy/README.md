# MINGWE GitHub copy pack — Add Liquidity integration

This is the next frontend integration draft, not a deployable AMM by itself.

## Confirmed architecture
- Tezos Shadownet
- Temple via Beacon/Taquito Wallet API
- Existing MINGWE FA2: `KT1XWATXQf1kWP6hk8MYZnJeW1cX5vmcajs6`, token ID 0
- Taquito Batch API can combine contract calls into one operation group
- FA2 `update_operators` standard is owner/operator/token_id and supports add/remove

## Important status
- `amm/temple-add-liquidity.js` expects the AMM entrypoint `add_liquidity(token_amount : nat)` and a payable call with XTZ attached. This must exactly match the compiled AMM contract.
- AMM address is deliberately blank. Never fill with an unverified address.
- Token decimals are read from TzKT metadata and not guessed. If missing, code stops.
- This file is not yet enabled in the live index.html because the pool contract has not been compiled, tested, and deployed.
- This frontend snippet needs a JS module build/bundling step before copying into the existing single-file GitHub Pages page. Do not paste into a classic `<script>` without adapting `import`/`export`.

## Required tests before deployment
1. SmartPy compile and test scenario against the exact contract ABI.
2. On Shadownet: first LP deposit, subsequent proportional deposit, both swap directions, remove LP, slippage rejection, zero reserve, insufficient FA2 balance, failed approval/batch, operator revoked after successful deposit.
3. Verify actual FA2 metadata decimals and raw total supply from TzKT.
4. Check Temple simulation and operation confirmation; confirm operator state after batch.

## Sources
- Taquito Wallet API and Beacon/TZIP-10: https://taquito.io/docs/25.1.1/wallet_API/
- Taquito Batch API: https://taquito.io/docs/25.1.1/batch-api/
- SmartPy FA2 entrypoints: https://smartpy.tezos.com/manual/libraries/FA2-lib/entrypoints.html
- Shadownet TzKT API: https://api.shadownet.tzkt.io/
