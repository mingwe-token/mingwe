/**
 * MINGWE AMM — Temple/Beacon Add Liquidity integration (Shadownet)
 *
 * ABI contract assumption for the AMM draft:
 *   add_liquidity(token_amount : nat)
 * payable with the XTZ amount in Taquito's batch call options.
 * FA2 standard:
 *   update_operators(list of add_operator/remove_operator variants)
 *
 * Do not use until AMM_ADDRESS points to the verified deployed contract
 * and this exact ABI has been compiled/tested against its Michelson.
 */
export const MINGWE = Object.freeze({
  rpc: "https://rpc.shadownet.teztnets.com",
  tzkt: "https://api.shadownet.tzkt.io",
  fa2: "KT1XWATXQf1kWP6hk8MYZnJeW1cX5vmcajs6",
  tokenId: 0,
  amm: "", // Fill only after the AMM is deployed and verified.
});

export function parseTokenDecimals(metadata) {
  const value = metadata?.decimals;
  if (value === undefined || value === null || value === "") {
    throw new Error("MINGWE metadata has no decimals; refusing to guess raw units.");
  }
  const decimals = Number(value);
  if (!Number.isInteger(decimals) || decimals < 0 || decimals > 18) {
    throw new Error("Invalid FA2 decimals metadata.");
  }
  return decimals;
}

export async function fetchMingweMetadata(fetchImpl = fetch) {
  const url = `${MINGWE.tzkt}/v1/tokens?contract=${MINGWE.fa2}&tokenId=${MINGWE.tokenId}&limit=1`;
  const response = await fetchImpl(url, { headers: { accept: "application/json" } });
  if (!response.ok) throw new Error(`TzKT token metadata HTTP ${response.status}`);
  const rows = await response.json();
  if (!Array.isArray(rows) || rows.length !== 1) {
    throw new Error("MINGWE token ID 0 was not returned by TzKT.");
  }
  const token = rows[0];
  return {
    symbol: token.metadata?.symbol || "MINGWE",
    name: token.metadata?.name || "MINGWE",
    decimals: parseTokenDecimals(token.metadata),
    totalSupplyRaw: String(token.totalSupply ?? token.totalSupplyRaw ?? ""),
    tokenId: Number(token.tokenId),
    contract: token.contract?.address || MINGWE.fa2,
  };
}

export function toRawTokenAmount(displayAmount, decimals) {
  const input = String(displayAmount).trim();
  if (!/^(?:\d+)(?:\.\d+)?$/.test(input)) throw new Error("Enter a valid positive token amount.");
  const [whole, fraction = ""] = input.split(".");
  if (fraction.length > decimals) throw new Error(`Maximum ${decimals} decimal places.`);
  const raw = BigInt(whole) * (10n ** BigInt(decimals)) + BigInt((fraction + "0".repeat(decimals)).slice(0, decimals) || "0");
  if (raw <= 0n) throw new Error("Token amount must be greater than zero.");
  if (raw > BigInt(Number.MAX_SAFE_INTEGER)) return raw.toString();
  return Number(raw);
}

/**
 * Submit approval -> deposit -> revoke in ONE Tezos operation group.
 * This is not an AMM contract audit. If any operation fails, the protocol
 * rejects the whole manager operation; confirm behavior on Shadownet first.
 * xtzAmount is decimal XTZ (e.g. "20"), tokenAmountRaw comes from decimals.
 */
export async function addLiquidityWithTemple({ tezos, account, xtzAmount, tokenAmountRaw }) {
  if (!tezos || !account) throw new Error("Connect Temple on Shadownet first.");
  if (!MINGWE.amm || !/^KT1[1-9A-HJ-NP-Za-km-z]{33}$/.test(MINGWE.amm)) {
    throw new Error("AMM contract address is not configured/verified yet.");
  }
  const xtz = Number(xtzAmount);
  if (!Number.isFinite(xtz) || xtz <= 0) throw new Error("XTZ amount must be positive.");
  const raw = BigInt(tokenAmountRaw);
  if (raw <= 0n) throw new Error("MINGWE raw amount must be positive.");
  if (raw > BigInt(Number.MAX_SAFE_INTEGER)) {
    throw new Error("Raw amount exceeds Taquito JS safe integer; use a Micheline-safe parameter encoder before enabling.");
  }

  const fa2 = await tezos.wallet.at(MINGWE.fa2);
  const amm = await tezos.wallet.at(MINGWE.amm);
  const operator = { owner: account, operator: MINGWE.amm, token_id: MINGWE.tokenId };
  const batch = tezos.wallet.batch()
    .withContractCall(fa2.methods.update_operators([{ add_operator: operator }]))
    .withContractCall(amm.methods.add_liquidity(Number(raw)), { amount: xtz, mutez: false })
    .withContractCall(fa2.methods.update_operators([{ remove_operator: operator }]))
    ;

  const operation = await batch.send();
  await operation.confirmation(1);
  return { operationHash: operation.opHash };
}
